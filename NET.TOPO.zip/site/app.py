from flask import Flask, render_template, jsonify, request

app = Flask(__name__)


# --- Network State Logic ---
def get_base_topology():
    """Returns the base OS infrastructure in English."""
    return {
        "nodes": [
            {"id": "host", "label": "OS Host", "group": "host",
             "info": {"name": "OS Host", "role": "Linux Kernel Namespace",
                      "details": ["Root network namespace", "Owns the physical NIC", "Manages system routing"],
                      "syscalls": ["ip link", "ip route"]}},
            {"id": "eth0", "label": "eth0", "group": "nic", "info": {"name": "eth0", "role": "Physical NIC",
                                                                     "details": ["Internet Egress point",
                                                                                 "Handles external traffic"],
                                                                     "syscalls": ["ethtool eth0",
                                                                                  "ip addr show eth0"]}},
            {"id": "docker0", "label": "docker0", "group": "bridge",
             "info": {"name": "docker0", "role": "Linux Virtual Bridge",
                      "details": ["Default Gateway: 172.17.0.1", "Standard Docker bridge interface"],
                      "syscalls": ["brctl show docker0"]}},
            {"id": "iptables", "label": "iptables", "group": "iptables",
             "info": {"name": "iptables", "role": "Netfilter / NAT Engine",
                      "details": ["Handles MASQUERADE rules", "Manages port forwarding"],
                      "syscalls": ["iptables -t nat -L"]}},
            {"id": "internet", "label": "Internet", "group": "internet",
             "info": {"name": "Internet", "role": "External Network",
                      "details": ["Public Wide Area Network", "Global DNS Reachability"], "syscalls": ["ping 8.8.8.8"]}}
        ],
        "edges": [
            {"from": "host", "to": "docker0", "label": "hosts bridge", "group": "host"},
            {"from": "docker0", "to": "iptables", "label": "FORWARD path", "group": "firewall"},
            {"from": "iptables", "to": "eth0", "label": "POSTROUTING (NAT)", "group": "firewall"},
            {"from": "eth0", "to": "internet", "label": "WAN Egress", "group": "wan"},
            {"from": "host", "to": "eth0", "label": "controls NIC", "group": "host"}
        ],
        "packet_paths": []
    }


current_topology = get_base_topology()
container_count = 0


def deploy_container():
    global container_count
    container_count += 1
    c_id = container_count
    ip = f"172.17.0.{c_id + 1}"
    ns_id, v_h, v_n = f"ns{c_id}", f"veth{c_id}_h", f"veth{c_id}_n"

    current_topology["nodes"].extend([
        {"id": ns_id, "label": f"Container {c_id}\n({ip})", "group": "container",
         "info": {"name": f"Container {c_id}", "role": "Isolated Network Namespace",
                  "details": [f"IP Address: {ip}/16", "Gateway: 172.17.0.1", "Isolated via CLONE_NEWNET"],
                  "syscalls": ["ip addr", "ss -tlnp"]}},
        {"id": v_h, "label": "veth_host", "group": "veth",
         "info": {"name": "veth_host", "role": "veth Peer (Host Side)",
                  "details": ["Connected to docker0 bridge", "Operates at Layer 2"], "syscalls": ["ip link show"]}},
        {"id": v_n, "label": "veth_ns", "group": "veth",
         "info": {"name": "veth_ns", "role": "veth Peer (Container Side)",
                  "details": ["Renamed to eth0 inside namespace", "Direct pipe to host bridge"],
                  "syscalls": ["ethtool -S eth0"]}}
    ])
    current_topology["edges"].extend([
        {"from": v_h, "to": v_n, "label": "veth pair", "group": "veth"},
        {"from": "docker0", "to": v_h, "label": "bridge port", "group": "bridge"},
        {"from": v_n, "to": ns_id, "label": "moves to ns", "group": "ns"}
    ])
    current_topology["packet_paths"].append({
        "name": f"C{c_id} -> Internet",
        "color": "#ff79c6",
        "path": [ns_id, v_n, v_h, "docker0", "iptables", "eth0", "internet"]
    })


# Initialize with one container
deploy_container()


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/about")
def about():
    return render_template("about.html")


@app.route("/api/topology")
def topology():
    return jsonify(current_topology)


@app.route("/api/add_container", methods=["POST"])
def add():
    deploy_container()
    return jsonify({"status": "success"})


@app.route("/api/reset", methods=["POST"])
def reset():
    global current_topology, container_count
    current_topology = get_base_topology()
    container_count = 0
    deploy_container()
    return jsonify({"status": "success"})


if __name__ == "__main__":
    app.run(debug=True, port=5000)