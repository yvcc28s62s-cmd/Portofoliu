from machine import Pin, PWM
import time
import random

# --- Patient Configuration (Conceptual - NOT for real medical use) ---
PATIENT_FIRST_NAME = "John"
PATIENT_LAST_NAME = "Doe"
PATIENT_PHONE_NUMBER = "+1-555-123-4567"  # Fictional phone number
PATIENT_LOCATION = "Timiș"  # Fictional location (County)
PATIENT_NORMAL_HR_MIN = 55  # Patient-specific normal range
PATIENT_NORMAL_HR_MAX = 95

# --- Medical Configuration (Conceptual - NOT for real medical use) ---
LOW_HR_THRESHOLD_DEVIATION = -15  # BPM below patient's min
HIGH_HR_THRESHOLD_DEVIATION = 20   # BPM above patient's max
RATE_CHANGE_THRESHOLD = 10        # BPM change within 5 seconds
LOW_HR_MEDICATION = "Hypothetical HR Booster"
HIGH_HR_MEDICATION = "Hypothetical HR Reducer"
LED_PIN_NUMBER = 16
SPEAKER_PIN_NUMBER = 15
PWM_FREQUENCY = 1000
SOUND_DURATION_MS = 500
SIMULATE_INJECTION_DURATION_MS = 3000
REPORTING_INTERVAL_SECONDS = 24 * 60 * 60  # 24 hours
BASE_HOSPITAL_EMAIL = "@cardio.ro" # Fictional domain
BATTERY_CAPACITY_SECONDS = 24 * 60 * 60 * 3 # Simulate 3 days of battery
BATTERY_WARNING_LEVEL_PERCENT = 15

# --- Hospital Database with Best Reviewed Names and Fictional Emails (Conceptual - NOT for real medical use) ---
HOSPITAL_DATA = {
    "Alba": {"name": "Alba Iulia County Hospital", "email": "alba.iulia" + BASE_HOSPITAL_EMAIL},
    "Arad": {"name": "Arad Clinical County Hospital", "email": "arad" + BASE_HOSPITAL_EMAIL},
    "Argeș": {"name": "Pitești County Emergency Hospital", "email": "pitesti" + BASE_HOSPITAL_EMAIL},
    "Bacău": {"name": "Bacău County Emergency Hospital", "email": "bacau" + BASE_HOSPITAL_EMAIL},
    "Bihor": {"name": "Oradea County Emergency Hospital", "email": "oradea" + BASE_HOSPITAL_EMAIL},
    "Bistrița-Năsăud": {"name": "Bistrița County Emergency Hospital", "email": "bistrita" + BASE_HOSPITAL_EMAIL},
    "Botoșani": {"name": "Botoșani County Emergency Hospital", "email": "botosani" + BASE_HOSPITAL_EMAIL},
    "Brașov": {"name": "Brașov County Clinical Emergency Hospital", "email": "brasov" + BASE_HOSPITAL_EMAIL},
    "Brăila": {"name": "Brăila County Emergency Hospital", "email": "braila" + BASE_HOSPITAL_EMAIL},
    "Buzău": {"name": "Buzău County Emergency Hospital", "email": "buzau" + BASE_HOSPITAL_EMAIL},
    "Caraș-Severin": {"name": "Reșița County Emergency Hospital", "email": "resita" + BASE_HOSPITAL_EMAIL},
    "Cluj": {"name": "Cluj County Emergency Hospital", "email": "cluj" + BASE_HOSPITAL_EMAIL},
    "Constanța": {"name": "Constanța County Emergency Hospital", "email": "constanta" + BASE_HOSPITAL_EMAIL},
    "Covasna": {"name": "Covasna County Hospital", "email": "covasna" + BASE_HOSPITAL_EMAIL},
    "Dâmbovița": {"name": "Târgoviște County Emergency Hospital", "email": "targoviste" + BASE_HOSPITAL_EMAIL},
    "Dolj": {"name": "Craiova County Emergency Hospital", "email": "craiova" + BASE_HOSPITAL_EMAIL},
    "Galați": {"name": "Galați County Clinical Emergency Hospital", "email": "galati" + BASE_HOSPITAL_EMAIL},
    "Giurgiu": {"name": "Giurgiu County Emergency Hospital", "email": "giurgiu" + BASE_HOSPITAL_EMAIL},
    "Gorj": {"name": "Târgu Jiu County Emergency Hospital", "email": "targu.jiu" + BASE_HOSPITAL_EMAIL},
    "Harghita": {"name": "Miercurea Ciuc County Emergency Hospital", "email": "miercurea.ciuc" + BASE_HOSPITAL_EMAIL},
    "Hunedoara": {"name": "Deva County Emergency Hospital", "email": "deva" + BASE_HOSPITAL_EMAIL},
    "Ialomița": {"name": "Slobozia County Emergency Hospital", "email": "slobozia" + BASE_HOSPITAL_EMAIL},
    "Iași": {"name": "Sfântul Spiridon Clinical Emergency Hospital Iași", "email": "iasi" + BASE_HOSPITAL_EMAIL},
    "Ilfov": {"name": "Ponderas Academic Hospital (Bucharest)", "email": "ponderas.bucharest" + BASE_HOSPITAL_EMAIL},
    "Maramureș": {"name": "Baia Mare County Hospital", "email": "baia.mare" + BASE_HOSPITAL_EMAIL},
    "Mehedinți": {"name": "Drobeta-Turnu Severin County Emergency Hospital", "email": "drobeta" + BASE_HOSPITAL_EMAIL},
    "Mureș": {"name": "Târgu Mureș Clinical County Hospital", "email": "targu.mures" + BASE_HOSPITAL_EMAIL},
    "Neamț": {"name": "Piatra Neamț County Emergency Hospital", "email": "piatra.neamt" + BASE_HOSPITAL_EMAIL},
    "Olt": {"name": "Slatina County Hospital", "email": "slatina" + BASE_HOSPITAL_EMAIL},
    "Prahova": {"name": "Ploiești County Emergency Hospital", "email": "ploiesti" + BASE_HOSPITAL_EMAIL},
    "Sălaj": {"name": "Zalău County Hospital", "email": "zalau" + BASE_HOSPITAL_EMAIL},
    "Satu Mare": {"name": "Satu Mare County Hospital", "email": "satu.mare" + BASE_HOSPITAL_EMAIL},
    "Sibiu": {"name": "Sibiu County Clinical Emergency Hospital", "email": "sibiu" + BASE_HOSPITAL_EMAIL},
    "Suceava": {"name": "Suceava County Emergency Hospital", "email": "suceava" + BASE_HOSPITAL_EMAIL},
    "Teleorman": {"name": "Alexandria County Hospital", "email": "alexandria" + BASE_HOSPITAL_EMAIL},
    "Timiș": {"name": "Timisoara Institute of Cardiovascular Medicine", "email": "iccv.timisoara" + BASE_HOSPITAL_EMAIL},
    "Tulcea": {"name": "Tulcea County Emergency Hospital", "email": "tulcea" + BASE_HOSPITAL_EMAIL},
    "Vaslui": {"name": "Vaslui County Emergency Hospital", "email": "vaslui" + BASE_HOSPITAL_EMAIL},
    "Vâlcea": {"name": "Râmnicu Vâlcea County Emergency Hospital", "email": "ramnicu.valcea" + BASE_HOSPITAL_EMAIL},
    "Vrancea": {"name": "Focșani County Emergency Hospital", "email": "focsani" + BASE_HOSPITAL_EMAIL},
    "Bucharest": {"name": "Ponderas Academic Hospital", "email": "ponderas.bucharest" + BASE_HOSPITAL_EMAIL},
}

# --- Initialize Hardware ---
led = Pin(LED_PIN_NUMBER, Pin.OUT)
speaker = PWM(Pin(SPEAKER_PIN_NUMBER))
speaker.freq(PWM_FREQUENCY)
speaker.duty_u16(0)
led.off()

# --- Fictional Injection Database ---
injection_log = []
last_report_time = 0
heart_rate_history = []
last_heart_rate_time = 0
battery_level_seconds = BATTERY_CAPACITY_SECONDS

def get_simulated_heart_rate():
    base_rate = random.randint(PATIENT_NORMAL_HR_MIN - 5, PATIENT_NORMAL_HR_MAX + 5)
    noise = random.uniform(-2, 2)
    anomaly_chance = 0.05
    if random.random() < anomaly_chance:
        return random.randint(PATIENT_NORMAL_HR_MIN - 25, PATIENT_NORMAL_HR_MIN - 10) if random.random() < 0.5 else random.randint(PATIENT_NORMAL_HR_MAX + 10, PATIENT_NORMAL_HR_MAX + 30)
    return base_rate + noise

def play_warning_beep():
    speaker.duty_u16(32767)
    time.sleep_ms(SOUND_DURATION_MS)
    speaker.duty_u16(0)

def simulate_injection(medication_name, quantity):
    """Simulates medication injection with a feedback effect."""
    global heart_rate_history
    print(f"SIMULATING INJECTION of {quantity:.2f} units of {medication_name}...")
    led.on()
    time.sleep_ms(SIMULATE_INJECTION_DURATION_MS)
    led.off()
    log_injection(medication_name, quantity)
    # Simulate feedback on heart rate
    if medication_name == LOW_HR_MEDICATION:
        for _ in range(5):
            heart_rate_history[-1] = heart_rate_history[-1] + 2 # Gradual increase
    elif medication_name == HIGH_HR_MEDICATION:
        for _ in range(5):
            heart_rate_history[-1] = max(20, heart_rate_history[-1] - 3) # Gradual decrease

def log_injection(medication, quantity):
    """Logs the injection details to the in-memory database."""
    now = time.localtime()
    timestamp = "{:04d}-{:02d}-{:02d} {:02d}:{:02d}".format(now[0], now[1], now[2], now[3], now[4])
    injection_log.append({
        "medication": medication,
        "quantity": quantity,
        "timestamp": timestamp
    })
    print("Injection logged.")
    print("Current Injection Log:", injection_log)

def find_nearest_hospital_data(location):
    """Fictional function to find the nearest hospital data."""
    if location in HOSPITAL_DATA:
        return HOSPITAL_DATA[location]
    else:
        return {"name": "Nearest Cardiology Hospital (Location Unknown)", "email": "unknown" + BASE_HOSPITAL_EMAIL}

def simulate_email_sending():
    """Simulates sending an email with the injection log and error handling."""
    global injection_log
    global last_report_time
    global battery_level_seconds

    hospital_data = find_nearest_hospital_data(PATIENT_LOCATION)
    hospital_name = hospital_data["name"]
    hospital_email = hospital_data["email"]

    print(f"\n--- Simulating End-of-Day Report ({time.localtime()[0]}-{time.localtime()[1]}-{time.localtime()[2]}) ---")
    print(f"Recipient: {hospital_email}")
    print(f"Patient: {PATIENT_FIRST_NAME} {PATIENT_LAST_NAME}")
    print(f"Location: {PATIENT_LOCATION}")
    print(f"Nearest Cardiology Hospital: {hospital_name}")

    if injection_log:
        email_body = "Medication Administration Report for Patient {} {}:\n\n".format(PATIENT_FIRST_NAME, PATIENT_LAST_NAME)
        for log_entry in injection_log:
            email_body += f"Medication: {log_entry['medication']}, Quantity: {log_entry['quantity']}, Timestamp: {log_entry['timestamp']}\n"
        print("Email Body:\n", email_body)
    else:
        email_body = f"No medication was administered to Patient {PATIENT_FIRST_NAME} {PATIENT_LAST_NAME} during the reporting period."
        print("Email Body:", email_body)

    # Simulate email sending success/failure
    if random.random() < 0.95:
        print(f"SIMULATING: Email sent successfully to {hospital_email}.")
        injection_log = []  # Clear the log after sending (simulated)
        last_report_time = time.time() # Update the last report time
        simulate_sms_notification(hospital_name) # Simulate sending SMS
    else:
        print(f"SIMULATION: Email sending to {hospital_email} FAILED.")

def simulate_sms_notification(hospital_name):
    """Simulates sending an SMS notification to the patient."""
    print(f"\n--- Simulating SMS to Patient {PATIENT_FIRST_NAME} {PATIENT_LAST_NAME} ({PATIENT_PHONE_NUMBER}) ---")
    sms_message = f"Dear {PATIENT_FIRST_NAME}, based on recent monitoring, please schedule a visit with the cardiology doctor at {hospital_name} at your earliest convenience."
    print("SMS Message:", sms_message)
    print("SIMULATING: SMS sent to patient.")

if __name__ == "__main__":
    print("Conceptual Heart Rate Monitor with Advanced Simulation")
    last_report_time = time.time() # Initialize last report time
    battery_level_seconds = BATTERY_CAPACITY_SECONDS
    last_heart_rate = get_simulated_heart_rate()
    last_heart_rate_time = time.time()

    try:
        while True:
            current_time = time.time()
            simulated_heart_rate = get_simulated_heart_rate()
            heart_rate_history.append(simulated_heart_rate)
            if len(heart_rate_history) > 5:
                heart_rate_history.pop(0)

            print(f"Current Heart Rate: {simulated_heart_rate:.2f} BPM, Battery: {battery_level_seconds / BATTERY_CAPACITY_SECONDS * 100:.2f}%")

            low_hr_threshold = PATIENT_NORMAL_HR_MIN + LOW_HR_THRESHOLD_DEVIATION
            high_hr_threshold = PATIENT_NORMAL_HR_MAX + HIGH_HR_THRESHOLD_DEVIATION

            rapid_change = False
            if len(heart_rate_history) >= 2 and current_time - last_heart_rate_time >= 5:
                rate_change = abs(heart_rate_history[-1] - heart_rate_history[-2])
                if rate_change > RATE_CHANGE_THRESHOLD:
                    rapid_change = True
                    print(f"Rapid heart rate change detected: {rate_change:.2f} BPM in 5 seconds.")
                last_heart_rate_time = current_time

            administered_medication = False
            if simulated_heart_rate < low_hr_threshold:
                quantity = random.uniform(0.1, 0.5)
                print(f"LOW HEART RATE DETECTED: {simulated_heart_rate:.2f} BPM (Threshold: {low_hr_threshold:.2f}). Simulating injection of {quantity:.2f} units of {LOW_HR_MEDICATION}")
                play_warning_beep()
                simulate_injection(LOW_HR_MEDICATION, quantity)
                administered_medication = True
            elif simulated_heart_rate > high_hr_threshold or rapid_change:
                quantity = random.uniform(0.5, 1.0)
                print(f"HIGH HEART RATE DETECTED: {simulated_heart_rate:.2f} BPM (Threshold: {high_hr_threshold:.2f}). Simulating injection of {quantity:.2f} units of {HIGH_HR_MEDICATION}")
                play_warning_beep()
                simulate_injection(HIGH_HR_MEDICATION, quantity)
                administered_medication = True
            else:
                led.off()

            # Check if it's time to send the report (simulated 24-hour cycle)
            if current_time - last_report_time >= REPORTING_INTERVAL_SECONDS:
                simulate_email_sending()

            battery_level_seconds -= 1  # Simulate battery drain
            if battery_level_seconds / BATTERY_CAPACITY_SECONDS * 100 < BATTERY_WARNING_LEVEL_PERCENT:
                print("BATTERY LOW! Please recharge soon (simulated).")

            time.sleep(1)

    except KeyboardInterrupt:
        print("\nProgram stopped.")
    finally:
        led.off()
        speaker.deinit()
        print("Final Injection Log:", injection_log)