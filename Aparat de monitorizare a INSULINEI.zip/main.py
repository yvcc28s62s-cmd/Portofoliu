import time
import random

# --- Configurare ---
INTERVAL_SIMULARE = 2  # Secunde între fiecare pas de simulare
FISIER_DATE = 'simulare_insulina_pico.csv'

# --- Simulare Variabile Fiziologice ---
nivel_activitate = 500
consum_carbohidrati = 0
nivel_glucoza = 100

# --- Istoricul Nivelului de Glucoză ---
istoric_glucoza = []
lungime_istoric_glucoza = 5

# --- Factori de Sensibilitate la Insulină ---
sensibilitate_insulina = 1.0

# --- Praguri ---
PRAG_ACTIVITATE_RIDICATA = 700
PRAG_GLUCOZA_SCAZUTA = 70
PRAG_GLUCOZA_RIDICATA = 180
PRAG_CARBOHIDRATI_SEMNIFICATIVI = 60

# --- Rata Bazală de Insulină ---
rata_bazala = 1.0
LIMITE_RATA_BAZALA = (0.2, 2.5)

# --- Efectul Mesei ---
efect_masa_activ = False
durata_efect_masa = 60
contor_efect_masa = 0
crestere_rata_bazala_masa = 0.5

# --- Funcții Utilitare ---

def obtine_timestamp_pico():
    """Obține un timestamp simplu pentru Pico."""
    return str(time.time())  # Returnează timpul în secunde de la epoca

def salveaza_date_pico(activitate, carbohidrati, glucoza, rata):
    """Salvează datele de simulare într-un fișier pentru Pico."""
    timestamp = obtine_timestamp_pico()
    try:
        with open(FISIER_DATE, "a") as f:
            f.write(f"{timestamp},{activitate},{carbohidrati},{glucoza},{rata}\n")
    except OSError as e:
        print(f"Eroare la scrierea în fișier: {e}")

def calculeaza_tendinta_glucoza_pico():
    """Calculează tendința nivelului de glucoză pentru Pico."""
    if len(istoric_glucoza) < 2:
        return 0
    return istoric_glucoza[-1] - istoric_glucoza[0]

def simuleaza_schimbare_nivel_glucoza_pico(activitate, carbohidrati, rata_bazala_curenta):
    """Simulează schimbarea nivelului de glucoză pentru Pico."""
    schimbare = 0
    schimbare -= activitate / 200
    if consum_carbohidrati > 0:
        schimbare += consum_carbohidrati / 50
    schimbare -= rata_bazala_curenta * sensibilitate_insulina / 2
    schimbare += random.uniform(-0.5, 0.5)
    return schimbare

# --- Logica Principală de Ajustare a Ratei Bazale ---

def ajusteaza_rata_bazala_complex_pico(activitate, carbohidrati, glucoza):
    """Ajustează rata bazală pentru Pico."""
    global sensibilitate_insulina

    rata_noua = rata_bazala

    tendinta_glucoza = calculeaza_tendinta_glucoza_pico()

    if glucoza < PRAG_GLUCOZA_SCAZUTA:
        rata_noua *= 0.8
    elif glucoza > PRAG_GLUCOZA_RIDICATA:
        rata_noua *= 1.2

    if activitate > PRAG_ACTIVITATE_RIDICATA:
        rata_noua *= 0.9
    elif activitate < PRAG_ACTIVITATE_RIDICATA / 3:
        rata_noua *= 1.1

    global efect_masa_activ, contor_efect_masa, crestere_rata_bazala_masa
    if carbohidrati > PRAG_CARBOHIDRATI_SEMNIFICATIVI and not efect_masa_activ:
        efect_masa_activ = True
        contor_efect_masa = durata_efect_masa
        crestere_rata_bazala_masa = carbohidrati / 150
        print(f"{obtine_timestamp_pico()} - Masă semnificativă detectată. Creștere temporară a ratei bazale.")

    if efect_masa_activ:
        rata_noua += crestere_rata_bazala_masa
        contor_efect_masa -= 1
        if contor_efect_masa <= 0:
            efect_masa_activ = False
            crestere_rata_bazala_masa = 0
            print(f"{obtine_timestamp_pico()} - Efectul mesei s-a încheiat.")

    if tendinta_glucoza > 5 and glucoza < PRAG_GLUCOZA_RIDICATA - 10:
        rata_noua *= 1.05
    elif tendinta_glucoza < -5 and glucoza > PRAG_GLUCOZA_SCAZUTA + 10:
        rata_noua *= 0.95

    if random.random() < 0.05:
        sensibilitate_insulina += random.uniform(-0.05, 0.05)
        sensibilitate_insulina = max(0.5, min(1.5, sensibilitate_insulina))
        print(f"{obtine_timestamp_pico()} - Sensibilitatea la insulină s-a modificat la {sensibilitate_insulina:.2f}.")

    return max(LIMITE_RATA_BAZALA[0], min(LIMITE_RATA_BAZALA[1], rata_noua))

# --- Bucla Principală de Simulare ---

if __name__ == "__main__":
    print("Simulare inteligentă a gestionării insulinei pentru Raspberry Pi Pico a început...")
    try:
        while True:
            nivel_activitate = int(max(0, min(1000, nivel_activitate + random.randint(-50, 50))))
            consum_carbohidrati = 0  # Asigurăm că este definit la începutul fiecărei iteratii
            if random.random() < 0.1:
                consum_carbohidrati = random.randint(0, 80)

            rata_bazala = ajusteaza_rata_bazala_complex_pico(nivel_activitate, consum_carbohidrati, nivel_glucoza)

            delta_glucoza = simuleaza_schimbare_nivel_glucoza_pico(nivel_activitate, consum_carbohidrati, rata_bazala)
            nivel_glucoza += delta_glucoza
            nivel_glucoza = max(30, min(300, nivel_glucoza))

            istoric_glucoza.append(nivel_glucoza)
            if len(istoric_glucoza) > lungime_istoric_glucoza:
                istoric_glucoza.pop(0)

            salveaza_date_pico(nivel_activitate, consum_carbohidrati, nivel_glucoza, rata_bazala)

            print(f"{obtine_timestamp_pico()} - Activitate: {nivel_activitate}, Carbohidrați: {consum_carbohidrati}, Glucoză: {nivel_glucoza:.2f} mg/dL, Rata Bazală: {rata_bazala:.2f} U/h")

            time.sleep(INTERVAL_SIMULARE)

    except KeyboardInterrupt:
        print("\nSimularea s-a încheiat.")